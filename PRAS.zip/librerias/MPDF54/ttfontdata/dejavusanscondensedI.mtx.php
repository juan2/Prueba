<?php
$name='DejaVuSansCondensed-Oblique';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 68,
  'FontBBox' => '[-914 -350 1493 1068]',
  'ItalicAngle' => -11,
  'StemV' => 87,
  'MissingWidth' => 540,
);
$up=-63;
$ut=44;
$ttffile='C:/gobtam/www/intranet/MPDF54/ttfonts/DejaVuSansCondensed-Oblique.ttf';
$TTCfontID='0';
$originalsize=489032;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusanscondensedI';
$panose='0 0 2 11 6 6 3 3 4 11 2 4';
$haskerninfo=false;
?>